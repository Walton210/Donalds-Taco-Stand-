from breezypythongui import EasyFrame
from tkinter import PhotoImage
from tkinter.font import Font
import tkinter as tk
#Main Module
class TacoStand(EasyFrame):
    #Setting up buttons and the main screen
    def __init__(self):
        EasyFrame.__init__(self, title = "Donald Taco Stand!")
        self.setResizable(False);
        MainImage = self.addLabel(text = "", row = 0, column = 0, columnspan = 3, sticky = "NSEW")
        MainTitle = self.addLabel(text = "Donald's Taco Stand!", row = 1, column = 0, columnspan = 3, sticky = "NSEW")
        
        #The Soft Taco Area
        self.addLabel (text = "Soft Taco $1.50", row = 2, column = 0, sticky = "NSEW")
        self.SoftTacoField = self.addIntegerField(value = 0 , row = 2, column = 1, sticky = "NSEW")
        #needs command self.SoftTaco
        self.addButton(text = "Customize", row = 2, column = 2, command = self.SoftTaco)

        #The Hard Taco Area
        self.addLabel (text = "Hard Taco $1.75", row = 3, column = 0, sticky = "NSEW")
        self.HardTacoField = self.addIntegerField(value = 0, row = 3, column = 1, sticky = "NSEW")
        #needs command self.HardTaco
        self.addButton(text = "Customize", row = 3, column =2, command = self.HardTaco)

        #The Burrito Area
        self.addLabel (text = "Burrito $2.00", row = 4, column = 0, sticky = "NSEW")
        self.BurritoField = self.addIntegerField(value = 0, row = 4, column = 1, sticky = "NSEW")
        #needs command self.Burrito
        self.addButton(text = "Customize", row = 4, column = 2, command = self.Burrito)

        #Calculate Button calculate command
        self.addButton(text = "Calculate", row = 5, column = 1, command = self.compute)

        #Tax total
        self.addLabel(text = "Tax Total $", row = 6, column = 0)
        self.TaxTotalField = self.addIntegerField(value = [], row = 6, column = 1, state = "readonly")
        #Total total
        self.addLabel(text = "Total $", row = 7, column =0)
        self.TotalTotalField = self.addIntegerField(value = [], row =7, column =1, state = "readonly")

        #add a clear button
        self.addButton(text = "Clear", row = 8, column =1, command = self.Clear)
        SmileyImage = self.addLabel(text = "", row = 8, column = 2, sticky = "NSEW")

         #importing the Main Menu image
        self.image = PhotoImage(file = "taco.gif")
        MainImage["image"] = self.image
        #changing the Main Menu text to blue.
        font = Font(family = "Verdana", size = 18, slant = "italic")
        MainTitle["font"] = font
        MainTitle["foreground"] = "blue"
        self.smiley = PhotoImage(file = "smiley.gif")
        SmileyImage["image"] = self.smiley
         #clear button
    def Clear(self):
        self.SoftTacoField = self.addIntegerField(value = 0 , row = 2, column = 1, sticky = "NSEW")
        self.HardTacoField = self.addIntegerField(value = 0, row = 3, column = 1, sticky = "NSEW")
        self.BurritoField = self.addIntegerField(value = 0, row = 4, column = 1, sticky = "NSEW")
        self.TaxTotalField = self.addIntegerField(value = [], row = 6, column = 1, state = "readonly")
        self.TotalTotalField = self.addIntegerField(value = [], row =7, column =1, state = "readonly")
        
        
       

    #Calculate command
    def compute(self):
        try:
            STF = self.SoftTacoField.getNumber()
            HTF = self.HardTacoField.getNumber()
            BF = self.BurritoField.getNumber()
            if STF < 0 or HTF < 0 or BF < 0: self.messageBox(title = "ERROR", message = "Input must be >= 0.")
            else:
                STFPrice = round(STF) * 1.50
                HTFPrice = round(HTF) * 1.75
                BFPrice = round(BF) * 2.00
                Total = STFPrice + HTFPrice + BFPrice
                TotalTax = round((Total * .07), 2)
                Totaltotal = Total + TotalTax
                self.TaxTotalField.setNumber(TotalTax)
                self.TotalTotalField.setNumber(Totaltotal)
        except ValueError:
                self.messageBox(title = "Error", message = "Input must be a number.")
    #upcoming remote food customization            
    def SoftTaco(self):
        self.messageBox(title = "Uh-oh!", message = "Oh no! This wasn't suppose to be here yet! Please see the cashier to customize!")
    def HardTaco(self):
        self.messageBox(title = "Uh-oh!", message = "Oh no! This wasn't suppose to be here yet! Please see the cashier to customize!")
    def Burrito(self):
        self.messageBox(title = "Uh-oh!", message = "Oh no! This wasn't suppose to be here yet! Please see the cashier to customize!")
   
        

       
    
def main():
    TacoStand().mainloop()
if __name__ == "__main__":
    main()
